package Prova02;

public class Paciente extends Pessoas {
	private String DataInicioSintomas;

	public String getDataInicioSintomas() {
		return DataInicioSintomas;
	}

	public void setDataInicioSintomas(String dataInicioSintomas) {
		DataInicioSintomas = dataInicioSintomas;
	}
	
	
}
