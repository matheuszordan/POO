// Nome : Matheus Pinheiro de Abreu Zordan Matricula: UC18200512
package Prova02;
import java.util.ArrayList;
import java.util.Scanner;
public class Teste {
	static double soma;
	static int cont;
	Scanner leia = new Scanner(System.in);
	public static void main(String args[]) {
		Scanner leia = new Scanner(System.in);
		ArrayList<Pessoas> pessoas = new ArrayList<Pessoas>();
		soma=0;
		cont=0;
		int flag;
		int exit;
		do {
			System.out.println("Informe o resultado do Teste de COVID-19");
			System.out.println("1-Negativo");
			System.out.println("2-Positivo");
			System.out.println("0-Sair");
			switch(leia.nextInt()) {
			case 1 : 
				Pessoas Pessoa = new Pessoas ();
				System.out.println("Informe o nome da Pessoa : ");
				Pessoa.setNome(leia.next());
				System.out.println("Digite a cidade satelite da pessoa:");
				Pessoa.setCidade(leia.next());
				Pessoa.add(Pessoa);
				break;
			case 2: 
				Pessoas Paciente = new Paciente ();
				System.out.println("Informe o nome da Pessoa : ");
				Paciente.setNome(leia.next());
				System.out.println("Digite a cidade satelite da pessoa:");
				Paciente.setCidade(leia.next());
				System.out.println("Informe a data do inicio dos sintomas : ");
				Paciente.Paciente.setDataInicioSintomas(leia.next());
				Pessoa.add(Paciente);
				cont++;
				break;
			case 0 :
				exit=0;
			}
			
		}while(exit==0);
		
		for (int i = 0; i < Pessoas.length; i++) {
			System.out.println("Quantidade de pessoas "+(i+1));
			System.out.println("Quantidade de pacientes "+cont);
		
			}
		}
	}

