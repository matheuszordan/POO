package Prova02;

public class Pessoas {
	private String nome;
	private String cidade;
	 int Resultado;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public int isResultado() {
		return Resultado;
	}
	public void setResultado(int resultado) {
		Resultado = resultado;
	}
	public void add(Pessoas pessoa) {
		// TODO Auto-generated method stub
		
	}

	
}
